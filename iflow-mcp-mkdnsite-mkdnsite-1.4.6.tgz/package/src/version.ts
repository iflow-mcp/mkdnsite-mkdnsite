// Generated at build/release time. Do not edit manually.
// For local dev, run: bun run version:generate
export const VERSION = '1.4.5'